import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-academica',
  templateUrl: './academica.component.html',
  styleUrls: ['./academica.component.css']
})
export class AcademicaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
