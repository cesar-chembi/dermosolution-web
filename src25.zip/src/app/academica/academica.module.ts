import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AcademicaComponent } from './academica.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [AcademicaComponent],
  exports:[AcademicaComponent]
})
export class AcademicaModule { }
