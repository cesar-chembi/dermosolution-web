export interface Paciente {
  id: number;
  nombre: string;
  nacionalidad:string;
  edad:number;
  sexo:string;
  documento:string;
  tipodocumento:string;
}
