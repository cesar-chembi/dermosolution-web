import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-casoreclamado-detalle',
  templateUrl: './casoreclamado-detalle.component.html',
  styleUrls: ['./casoreclamado-detalle.component.css']
})
export class CasoreclamadoDetalleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
