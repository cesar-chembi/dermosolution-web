import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-casodermatologico',
  templateUrl: './casodermatologico.component.html',
  styleUrls: ['./casodermatologico.component.css']
})
export class CasodermatologicoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
