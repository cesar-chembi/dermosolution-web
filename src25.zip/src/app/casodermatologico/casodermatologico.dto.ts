
export class CasodermatologicoDTO {
    readonly id!: number;

    constructor() { }


}
