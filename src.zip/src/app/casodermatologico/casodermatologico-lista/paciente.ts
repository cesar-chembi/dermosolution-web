export interface Paciente {
  id: number;
  nombres: string;
  apellidos: string;
  fecha_nacimiento:string;
  lugar_nacimiento:string;
  lugar_residencia:string;
  numero_celular:string;
  correo:string;
  //nacionalidad:string;
  edad:number;
  sexo:string;
  //documento:string;
  //tipodocumento:string;
  //lugarresidencia:string;

}
