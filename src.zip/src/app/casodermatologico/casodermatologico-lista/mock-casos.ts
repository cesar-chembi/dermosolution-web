import { Caso } from './caso';

export const CASOS: Caso[] = [

];

