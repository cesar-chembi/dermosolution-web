import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Caso } from '../casodermatologico-lista/caso';
import { HttpClient } from '@angular/common/http';
import {environment} from "../../../environments/environment";





@Injectable({
  providedIn: 'root'
})
export class CasodermatologicoDetalleService {

  urlPaciente: string = environment.urlPaciente;
  urlCasoMedico: string = environment.urlMedico;

constructor(private http: HttpClient) { }


getReclamadosDetalle(identificadorpacinete: number): Observable<Caso>{
  return this.http.get<Caso>(this.urlPaciente+identificadorpacinete+'/casos-medicos/');
}



}
