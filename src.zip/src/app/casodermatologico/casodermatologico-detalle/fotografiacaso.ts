export interface Fotografiacaso {
identificador: string;
url: string;
}
