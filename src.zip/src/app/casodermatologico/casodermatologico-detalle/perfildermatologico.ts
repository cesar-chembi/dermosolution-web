export interface Perfildermatologico {
 formalesion:string;
 tipolesion: string;
 numerolesion: string;
 colorlesion: string;
 localizacionlesion: string;
}
