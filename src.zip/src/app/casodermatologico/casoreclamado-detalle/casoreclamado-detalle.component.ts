import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Caso } from '../casodermatologico-lista/caso';
import { CasoreclamadoDetalleService } from './casoreclamado-detalle.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import {Message,MessageService} from 'primeng/api';
import { Diagnostico } from './diagnostico';


@Component({
  selector: 'app-casoreclamado-detalle',
  templateUrl: './casoreclamado-detalle.component.html',
  styleUrls: ['./casoreclamado-detalle.component.css']
})
export class CasoreclamadoDetalleComponent implements OnInit {

  msgs2: Message[];

  diagnosticoobjeto: Diagnostico;
  caso : Caso;
  diagnostico : string;
  items = ["item1", "item2", "item3", "item4", "item5"];
  resultado: string;
  aceptado : boolean = true;
  idmedico:string;
	responsiveOptions: any[];
  constructor(private casoreclamadoDetalleService: CasoreclamadoDetalleService,
     private route: ActivatedRoute
    ) {
    this.responsiveOptions = [
      {
          breakpoint: '1024px',
          numVisible: 3,
          numScroll: 3
      },
      {
          breakpoint: '768px',
          numVisible: 2,
          numScroll: 2
      },
      {
          breakpoint: '560px',
          numVisible: 1,
          numScroll: 1
      }
  ];
}



  ngOnInit() {

    this.idmedico = this.route.snapshot.paramMap.get('id')!;
    let idpaciente = this.route.snapshot.paramMap.get('idpaciente')!;
    this.consultarDetalleReclamadoPorId(parseInt(this.idmedico),parseInt(idpaciente));
  }



  consultarDetalleReclamadoPorId(identificadorcaso: number, identificadorpaciente: number): void {
    this.casoreclamadoDetalleService.getReclamadosDetalle(identificadorpaciente).subscribe(
       casos => {
        this.caso = casos[0];
      }
       );

       console.log(this.caso[0]);
    }


  actualizarDiagnostico():void{
    console.log('aguas el diagnostico')
    console.log(this.diagnostico)
    let date: Date = new Date();

    this.diagnosticoobjeto = new Diagnostico(this.caso.id,"2023-02-05",this.diagnostico, parseInt(this.idmedico),this.aceptado,"2023-02-05");
    this.casoreclamadoDetalleService.actualizarDiagnosticoCaso(
      this.caso.id, parseInt(this.idmedico) ,
      this.diagnostico, this.aceptado, "2023-02-05", this.diagnosticoobjeto)
    .subscribe(rta => {
      console.log(rta)
        if (rta != null){

        this.msgs2 = [({severity:'success',
        summary:'Success', detail:'El diagnostico medico se registro correctamente'})];


      }else{

        this.msgs2 = [(
           {severity:'error', summary:'Error',
           detail:'No fue posible registrar el diagnostico del caso medico, intenta de nuevo'})];

      }

  });


  }




  diagnosticoform = new FormGroup({
    diagnostico: new FormControl('', [Validators.required])
     });

  submit() {
    if (this.diagnosticoform.valid)
      this.resultado = "Todos los datos son válidos";
    else
      this.resultado = "Hay datos inválidos en el formulario";
  }




  }



