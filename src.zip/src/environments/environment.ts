const host = 'http://localhost:8000/';
//const host = 'https://dermosbkend.onrender.com/';

export const environment = {
  production: false,
  urlMedico: `${host}api/v1/medicos/`,
  urlPaciente: `${host}api/v1/pacientes/`,
  urlEspecialidad: `${host}api/v1/especialiades/`,
  urlEspecialidadMedico: `${host}api/v1/medicosespecialidad/`

}


