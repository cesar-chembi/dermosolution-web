

describe('Verificacion de las prueba', function() {
  var a;
  it('and so is a spec', function() {
    a= true;
   expect(a).toBe(true)

  });
 });

