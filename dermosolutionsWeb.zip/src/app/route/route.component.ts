import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-route',
  templateUrl: './route.component.html'

})
export class RouteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
