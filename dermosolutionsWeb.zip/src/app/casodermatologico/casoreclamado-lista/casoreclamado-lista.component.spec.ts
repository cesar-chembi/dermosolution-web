import { CasoreclamadoListaComponent } from './casoreclamado-lista.component';
import { CasoreclamadoListaService } from './casoreclamado-lista.service';
import { Router } from '@angular/router';
import { HttpClient, HttpHandler } from '@angular/common/http';

/*
describe('CasoreclamadoListaComponent', () => {
  let component: CasoreclamadoListaComponent;
  let service: CasoreclamadoListaService;
  let router: Router;
  let clienteHttp: HttpClient;
  let handler: HttpHandler;


  beforeEach(() => {
    clienteHttp = new HttpClient(handler)
    service = new CasoreclamadoListaService(clienteHttp);
    router = new Router();
    component = new CasoreclamadoListaComponent(service, router);
  });


  it('validar que la lista de casos no sea vacia', () => {
      expect(component.listasexo.length > 0);
  });

  it('validar que la lista de casos no sea vacia', () => {
    expect(component.listapaises.length > 0);
  });

  describe('Verificacion de las prueba caso dermatolo', function() {
    var a;
    it('and so is a spec', function() {
      a= true;
     expect(a).toBe(true)

    });
   });

});
*/
