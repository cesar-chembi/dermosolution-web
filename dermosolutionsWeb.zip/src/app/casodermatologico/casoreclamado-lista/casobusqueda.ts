export interface Casobusqueda {
  identificador: string;
  fechainicio: string;
  fechafinal: string;
  nombrepaciente: string;
  edad: number;
  nacionalidad: string;
  sexo: string;
  descripcion: string;
  estado:string;
}


