import { TestBed,  inject } from '@angular/core/testing';
import { CasoreclamadoListaService } from './casoreclamado-lista.service';

/*
describe('Service: CasoreclamadoLista', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CasoreclamadoListaService]
    });
  });

  it('should ...', inject([CasoreclamadoListaService], (service: CasoreclamadoListaService) => {
    expect(service).toBeTruthy();
  }));
});

*/
