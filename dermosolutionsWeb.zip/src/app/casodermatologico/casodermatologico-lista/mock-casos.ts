import { Caso } from './caso';

export const CASOS: Caso[] = [
  { id: 1, fecharegistro: '20/12/2022',
  paciente:{ nombre:'Pedro Perez', documento: '1111111', edad:20, id:1,
  nacionalidad:'colombia', sexo:'Masculino',
  tipodocumento:'Cedula', lugarresidencia:'Bogota'},
  perfildermatologico: { formalesion: "formalesion", tipolesion: "tipolesion", numerolesion: "numerolesion",
  colorlesion: "colorlesion", localizacionlesion: "localizacion"},
  diagnostico:"diagnostico",
  fotografias:

  [
    {
      "identificador": "1",
      "url": "www.google.com",
    },

    {
      "identificador": "2",
      "url": "www.google.com",
    },
    {
      "identificador": "3",
      "url": "www.google.com",
    }

  ],
  descripcion:"descripcion",
  estado: "2"
  }
];

