import { ComponentFixture } from '@angular/core/testing';
import { CasodermatologicoListaComponent } from './casodermatologico-lista.component';
import { CasodermatologicoListaService} from './casodermatologico-lista.service'

describe('CasodermatologicoListaComponent', () => {
  let component: CasodermatologicoListaComponent;
  let service: CasodermatologicoListaService;

it('validar en el servicio que la lista de casos no sea vacia', () => {
    expect(service.getCasos.length > 0);
});

});
