/* tslint:disable:no-unused-variable */
import { ComponentFixture } from '@angular/core/testing';
import { CasodermatologicoDetalleComponent } from './casodermatologico-detalle.component';


describe('CasodermatologicoDetalleComponent', () => {
  let component: CasodermatologicoDetalleComponent;
  let fixture: ComponentFixture<CasodermatologicoDetalleComponent>;


  describe('Verificacion de las prueba caso dermatolo', function() {
    var a;
    it('and so is a spec', function() {
      a= true;
     expect(a).toBe(true)

    });
   });

  });

