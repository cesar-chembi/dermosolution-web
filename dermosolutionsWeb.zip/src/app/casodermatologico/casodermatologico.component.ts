import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-casodermatologico',
  templateUrl: './casodermatologico.component.html'

})
export class CasodermatologicoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
